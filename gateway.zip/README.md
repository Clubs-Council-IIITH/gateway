# gateway

Apollo Gateway for Federated GraphQL Microservices
